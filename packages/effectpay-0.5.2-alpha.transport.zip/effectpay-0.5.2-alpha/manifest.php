<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectpay-0.5.2-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3e189630a3fb2324b920e1d416e6cbae',
      'native_key' => 'effectpay',
      'filename' => 'modNamespace/f02bae3a676e4a9d20e2bc2fa441890f.vehicle',
      'namespace' => 'effectpay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '4302fadd295966aca69b1adfedff7282',
      'native_key' => '4302fadd295966aca69b1adfedff7282',
      'filename' => 'xPDOScriptVehicle/373b48afa4955c46d90beb1286e13bc0.vehicle',
      'namespace' => 'effectpay',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5108bb2b6aab941cf1cb77294c6ff7e',
      'native_key' => 'PayCallback',
      'filename' => 'modEvent/d40b70413d5a0f981810fc4bfec73b8e.vehicle',
      'namespace' => 'effectpay',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '269586dba4191f6f726c448930f97c7a',
      'native_key' => 0,
      'filename' => 'modCategory/5efe6401dc46ca1f56e78acb7056b97c.vehicle',
      'namespace' => 'effectpay',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5240e62e5f889c060f8de47b67bfc02',
      'native_key' => 'effectpay.shop',
      'filename' => 'modSystemSetting/9fe38cceec37cf1478d725a557ef7287.vehicle',
      'namespace' => 'effectpay',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8e4cdb8d228b1693cd5ed3c67914369',
      'native_key' => 'effectpay.return_page',
      'filename' => 'modSystemSetting/5cf3f7d380b11a668d4665d71d015c78.vehicle',
      'namespace' => 'effectpay',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef030ce22827b23440a75e034a40047a',
      'native_key' => 'effectpay.merchant_email',
      'filename' => 'modSystemSetting/52a609bd1a977dc815fb45561830c8b4.vehicle',
      'namespace' => 'effectpay',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3d5879ebc07820a5d40b9396f33de30',
      'native_key' => 'effectpay.tax',
      'filename' => 'modSystemSetting/ae7f8a61d6a41ad85d5bc3a82fc857cd.vehicle',
      'namespace' => 'effectpay',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '127b5750fc099a54309a23efc751b1c9',
      'native_key' => 'effectpay.robokassa.id',
      'filename' => 'modSystemSetting/4d7343eb63fcba3668be56bd8bb2d551.vehicle',
      'namespace' => 'effectpay',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc38f5d385a08d591e5349fe58797443',
      'native_key' => 'effectpay.robokassa.is_test',
      'filename' => 'modSystemSetting/7b2b5bb04250d36fb8e83c0b89a0d57f.vehicle',
      'namespace' => 'effectpay',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f47363a131ea236b671e15c63811ae7',
      'native_key' => 'effectpay.robokassa.passwords',
      'filename' => 'modSystemSetting/33d2471bbb706fe11beed8bdb756d140.vehicle',
      'namespace' => 'effectpay',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd1b5b4d874aa5d2af5852a0a7495db5',
      'native_key' => 'effectpay.sberbank.id',
      'filename' => 'modSystemSetting/2ca7aba6ba8912040e14983b83f8f3e8.vehicle',
      'namespace' => 'effectpay',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c70f0ee28f0613b9250ef9388ac402c',
      'native_key' => 'effectpay.sberbank.is_test',
      'filename' => 'modSystemSetting/b3e84e6f1d627d4e60cc33c3ecc3db8d.vehicle',
      'namespace' => 'effectpay',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99240c5317de02c9c2745af192ba45c8',
      'native_key' => 'effectpay.sberbank.passwords',
      'filename' => 'modSystemSetting/7775d754adda45aded35cabfbf02c76a.vehicle',
      'namespace' => 'effectpay',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '782d75690de86c6393d155145c06108f',
      'native_key' => 'effectpay.paykeeper.id',
      'filename' => 'modSystemSetting/16ac1b0680f2abc13364f133f000d5dc.vehicle',
      'namespace' => 'effectpay',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b79ea704ed73d780d720674604596e5',
      'native_key' => 'effectpay.paykeeper.password',
      'filename' => 'modSystemSetting/03f74a38f85b75b14859a02e1d1d454f.vehicle',
      'namespace' => 'effectpay',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c5b85bad7dbe908f1d5c2d47f6cd9db',
      'native_key' => 'effectpay.paykeeper.server',
      'filename' => 'modSystemSetting/8970ec53cd8813d55c6ec1a180d02bea.vehicle',
      'namespace' => 'effectpay',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78de4da3dae002fd3ca6ab00d6ffd949',
      'native_key' => 'effectpay.paykeeper.secret',
      'filename' => 'modSystemSetting/b0fa175f38c478d21eba30b64f85b9cf.vehicle',
      'namespace' => 'effectpay',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0e27b90538ece1f1358b8ba83b65662',
      'native_key' => 'effectpay.alpha.id',
      'filename' => 'modSystemSetting/26dd178e5cfb395712167d4e96914967.vehicle',
      'namespace' => 'effectpay',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0192f73fcaf707671d0d14936a65b862',
      'native_key' => 'effectpay.alpha.password',
      'filename' => 'modSystemSetting/b33ac14b02fbe66259f9f38e859d6cbe.vehicle',
      'namespace' => 'effectpay',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dd35745adaa9db50668a8362082fb77',
      'native_key' => 'effectpay.psb.is_test',
      'filename' => 'modSystemSetting/bccb59ac73632b583e7ac4dc32af49cb.vehicle',
      'namespace' => 'effectpay',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d0aaea4801d1eaf6133b8d10116cbe4',
      'native_key' => 'effectpay.psb.terminal',
      'filename' => 'modSystemSetting/c5a5d12294cebead9582a993b564f308.vehicle',
      'namespace' => 'effectpay',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67f740a2908479cfd0f1a2ab28b698f6',
      'native_key' => 'effectpay.psb.merchant',
      'filename' => 'modSystemSetting/c480e8a403cb12e8077875ca335873cf.vehicle',
      'namespace' => 'effectpay',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cbcac351b71e1cd773d05cf8d8689ec',
      'native_key' => 'effectpay.psb.keys',
      'filename' => 'modSystemSetting/114fe61846214642196440b448dfef34.vehicle',
      'namespace' => 'effectpay',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f43d93eeacc89d7354403e2beaf11df5',
      'native_key' => 'effectpay.shk.statuses',
      'filename' => 'modSystemSetting/cbb1961856901e35d053846c669f6cd3.vehicle',
      'namespace' => 'effectpay',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '68691300d4f92f22826f8b5ca5e56eff',
      'native_key' => '68691300d4f92f22826f8b5ca5e56eff',
      'filename' => 'xPDOScriptVehicle/4c919de6cd0636053dcb4b1cf48a0899.vehicle',
      'namespace' => 'effectpay',
    ),
  ),
);