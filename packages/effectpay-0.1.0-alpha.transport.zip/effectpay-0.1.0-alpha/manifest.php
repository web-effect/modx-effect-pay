<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectpay-0.1.0-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '88d1ef67dcb994a4a026463e5cb83b21',
      'native_key' => 'effectpay',
      'filename' => 'modNamespace/045962bd20667655e94f3b2fb89af613.vehicle',
      'namespace' => 'effectpay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '99dafde11d54d1e57403cd71707f7a8b',
      'native_key' => '99dafde11d54d1e57403cd71707f7a8b',
      'filename' => 'xPDOScriptVehicle/4fd371f14281fe38d3e6ef351c9b1e94.vehicle',
      'namespace' => 'effectpay',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbd186b2e42036cfc2a40598eee9ab68',
      'native_key' => 'effectpay.robokassa.id',
      'filename' => 'modSystemSetting/d2b9c3815c7127c887bd1f8ef1060a03.vehicle',
      'namespace' => 'effectpay',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53a8de82ed02a2d785e3756ef575e160',
      'native_key' => 'effectpay.robokassa.is_test',
      'filename' => 'modSystemSetting/77fd9956c4846665a9bc233264334a98.vehicle',
      'namespace' => 'effectpay',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74387b052502166f5e87a3b97a5a9ebd',
      'native_key' => 'effectpay.robokassa.passwords',
      'filename' => 'modSystemSetting/efa6bc91c979c4e14272ed2a196810b1.vehicle',
      'namespace' => 'effectpay',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df4dd77131547ab707d27a01068ca032',
      'native_key' => 'effectpay.shk.statuses',
      'filename' => 'modSystemSetting/5d0996087c1c978bed0d3d45d25ae064.vehicle',
      'namespace' => 'effectpay',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ece2854175619149dd0864a828ea506d',
      'native_key' => 0,
      'filename' => 'modCategory/58cbfbd9b21273bcb8e039cfa0de845a.vehicle',
      'namespace' => 'effectpay',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '5ee6daacd32615ea1a621bbc14c69dc4',
      'native_key' => '5ee6daacd32615ea1a621bbc14c69dc4',
      'filename' => 'xPDOScriptVehicle/27577ff17c917fe1fa18d289169c1ea0.vehicle',
      'namespace' => 'effectpay',
    ),
  ),
);