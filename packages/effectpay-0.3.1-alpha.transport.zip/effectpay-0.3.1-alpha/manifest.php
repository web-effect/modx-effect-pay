<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectpay-0.3.1-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'db4119c7b533cbcf44f8e87dfea63b47',
      'native_key' => 'effectpay',
      'filename' => 'modNamespace/89834794ef5927b83675e2e20481443f.vehicle',
      'namespace' => 'effectpay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'e24d9bbd433a366881a088f6becf9774',
      'native_key' => 'e24d9bbd433a366881a088f6becf9774',
      'filename' => 'xPDOScriptVehicle/d5700449416bda1a87b9da453152dfb4.vehicle',
      'namespace' => 'effectpay',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '579b279fdac3075bd8423ae4959037b1',
      'native_key' => 0,
      'filename' => 'modCategory/612fb2fdfe481c53be6be85fa940c130.vehicle',
      'namespace' => 'effectpay',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91b00f7af6165deae30e50dc96d3b252',
      'native_key' => 'PayCallback',
      'filename' => 'modEvent/78b2f891ddf9e8388f374fef5367480a.vehicle',
      'namespace' => 'effectpay',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f57a29f21ca27aec2d89d3235fdd3185',
      'native_key' => 'effectpay.return_page',
      'filename' => 'modSystemSetting/4bbc1d119a7d7f2088c6ef9e869f7a76.vehicle',
      'namespace' => 'effectpay',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea373c0fa6f47ccd5a2f4b0093b822ca',
      'native_key' => 'effectpay.robokassa.id',
      'filename' => 'modSystemSetting/2b3b54fd7df99b251182572eca4fd501.vehicle',
      'namespace' => 'effectpay',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03d4814dbe86ba27f435fb4c3c514737',
      'native_key' => 'effectpay.robokassa.is_test',
      'filename' => 'modSystemSetting/480e4db044d1ed2bed93acec124339f2.vehicle',
      'namespace' => 'effectpay',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '401b682eca4d9809c123ca426218e0f6',
      'native_key' => 'effectpay.robokassa.passwords',
      'filename' => 'modSystemSetting/98e0ed6db95244fbfec424c3732cb1b1.vehicle',
      'namespace' => 'effectpay',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6ad81a7646fc44d21e6954e0c5772a3',
      'native_key' => 'effectpay.sberbank.id',
      'filename' => 'modSystemSetting/cb9bd0fa6e3041ca0eb87d09f8340a5b.vehicle',
      'namespace' => 'effectpay',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca2cd7bfaa1ddd1a80a5a52d870a2826',
      'native_key' => 'effectpay.sberbank.is_test',
      'filename' => 'modSystemSetting/eb5bd2152d550366471990e7a798a623.vehicle',
      'namespace' => 'effectpay',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26811d89491154ed3bea6afe86e8a298',
      'native_key' => 'effectpay.sberbank.passwords',
      'filename' => 'modSystemSetting/69f229d7fa84f791532f91be578368e8.vehicle',
      'namespace' => 'effectpay',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '109d75638b96b7cdbf521fc7cece3e28',
      'native_key' => 'effectpay.paykeeper.id',
      'filename' => 'modSystemSetting/02d77eb54a2151105978d462900c729d.vehicle',
      'namespace' => 'effectpay',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '595bf9bae56b7a843b5691fcfe2b0955',
      'native_key' => 'effectpay.paykeeper.password',
      'filename' => 'modSystemSetting/6c02ad393705da703170ba988f08028f.vehicle',
      'namespace' => 'effectpay',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8059174d20d2a56cb0a1808706b9c2d',
      'native_key' => 'effectpay.paykeeper.server',
      'filename' => 'modSystemSetting/847ea54c486c0402b53e21eed824a394.vehicle',
      'namespace' => 'effectpay',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cd5053d61a8db34adbef3c243a00f8b',
      'native_key' => 'effectpay.paykeeper.secret',
      'filename' => 'modSystemSetting/4327aaa4b1879902478291230e0d38a9.vehicle',
      'namespace' => 'effectpay',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8d87d7136e1ef9e25ac1edec4f2c950',
      'native_key' => 'effectpay.shk.statuses',
      'filename' => 'modSystemSetting/2e81474ed358ecf2524ea64b30e650fa.vehicle',
      'namespace' => 'effectpay',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'e0b6bba2d3370bd079860197af1246cf',
      'native_key' => 'e0b6bba2d3370bd079860197af1246cf',
      'filename' => 'xPDOScriptVehicle/213d0d6e957a7d586762a4870c2089e5.vehicle',
      'namespace' => 'effectpay',
    ),
  ),
);