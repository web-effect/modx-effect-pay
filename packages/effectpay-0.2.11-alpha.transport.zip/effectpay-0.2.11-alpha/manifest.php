<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectpay-0.2.11-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9c7b664cc3b1f3788b88bb42c9481367',
      'native_key' => 'effectpay',
      'filename' => 'modNamespace/68d676aa5fd9ffed242475b4387c1ff5.vehicle',
      'namespace' => 'effectpay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'bfa9db2575566e26ea28fc8803f326a1',
      'native_key' => 'bfa9db2575566e26ea28fc8803f326a1',
      'filename' => 'xPDOScriptVehicle/978f2338f428e63494df8b182e6b9e00.vehicle',
      'namespace' => 'effectpay',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3f6d25902e4bae1ce2418f22209dee51',
      'native_key' => 0,
      'filename' => 'modCategory/bb5e5d6fb6cb488a8b2802ee5288c4cb.vehicle',
      'namespace' => 'effectpay',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '689ad350bb326886b85eeab53b8c9a56',
      'native_key' => 'effectpay.return_page',
      'filename' => 'modSystemSetting/fd450c21449059b7e13d792a32d81aab.vehicle',
      'namespace' => 'effectpay',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a7d05305d35e719f869883904662c73',
      'native_key' => 'effectpay.robokassa.id',
      'filename' => 'modSystemSetting/a285dfeba43e12c4736a146f3f73d49a.vehicle',
      'namespace' => 'effectpay',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20389f0bb4be60daeeb30e1d246d847b',
      'native_key' => 'effectpay.robokassa.is_test',
      'filename' => 'modSystemSetting/152547cbee5d49a16586176b2d76af57.vehicle',
      'namespace' => 'effectpay',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56b0f3dbf0abc70aac7d865891f80667',
      'native_key' => 'effectpay.robokassa.passwords',
      'filename' => 'modSystemSetting/844863330e19f664c7df114fa5cddd1a.vehicle',
      'namespace' => 'effectpay',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bedca8d3e9e1f1a9293c12d4b23ea3c3',
      'native_key' => 'effectpay.sberbank.id',
      'filename' => 'modSystemSetting/dee2b50cf4bf017b98e29d06b89fb547.vehicle',
      'namespace' => 'effectpay',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb03ff5e8bb81a386973e22a7bfebc78',
      'native_key' => 'effectpay.sberbank.is_test',
      'filename' => 'modSystemSetting/7689b75b98272efa6767500837ff87b4.vehicle',
      'namespace' => 'effectpay',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f9729aab2e12212cac2aef8ee621675',
      'native_key' => 'effectpay.sberbank.passwords',
      'filename' => 'modSystemSetting/81cc5c0d1dc9f149ef8ecd6bd92ab2fb.vehicle',
      'namespace' => 'effectpay',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9e1ce01283693d045783524e39bb961',
      'native_key' => 'effectpay.shk.statuses',
      'filename' => 'modSystemSetting/b6c983b683b66534dd03adcddbaaa507.vehicle',
      'namespace' => 'effectpay',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1b4b346c488b950fa1fcc598d1823b5',
      'native_key' => 'PayCallback',
      'filename' => 'modEvent/07eaaee06c19d5a771a6c53d9db8b924.vehicle',
      'namespace' => 'effectpay',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'f2d3ecd828950e8d4b659c09d9e9e4f4',
      'native_key' => 'f2d3ecd828950e8d4b659c09d9e9e4f4',
      'filename' => 'xPDOScriptVehicle/1924a48ec42822855358a4adbb2a446a.vehicle',
      'namespace' => 'effectpay',
    ),
  ),
);