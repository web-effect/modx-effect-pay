<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectpay-0.2.0-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b95d16157b25182d8d4b0cfcafd698a4',
      'native_key' => 'effectpay',
      'filename' => 'modNamespace/f9c308a064fc62d8894d3cb909b33bc2.vehicle',
      'namespace' => 'effectpay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '92ee48704c5edc298b3e0d7006117c0d',
      'native_key' => '92ee48704c5edc298b3e0d7006117c0d',
      'filename' => 'xPDOScriptVehicle/50733a231ac62151749fc1609c50deb4.vehicle',
      'namespace' => 'effectpay',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e9913b600fc53a3f261bc65503f36d50',
      'native_key' => 0,
      'filename' => 'modCategory/e84d8f621769a11731436238bccc0d8d.vehicle',
      'namespace' => 'effectpay',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86d8071acdc2ed2970989afc23e47c80',
      'native_key' => 'effectpay.robokassa.id',
      'filename' => 'modSystemSetting/2c406c2a49736e3a28a543db4b680dae.vehicle',
      'namespace' => 'effectpay',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb24afb578c7227b512c662dc6437318',
      'native_key' => 'effectpay.robokassa.is_test',
      'filename' => 'modSystemSetting/2fab64d11dcadc5770fdc23dd00248d4.vehicle',
      'namespace' => 'effectpay',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '571063653a6662609f9029ecebb6f38e',
      'native_key' => 'effectpay.robokassa.passwords',
      'filename' => 'modSystemSetting/2b2a21cd2723bde8c4715a6074ae477d.vehicle',
      'namespace' => 'effectpay',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faa005c20b203724c05365a1523fe8e5',
      'native_key' => 'effectpay.sberbank.id',
      'filename' => 'modSystemSetting/630d9ee877d4a5533e6ea5ad5c819b75.vehicle',
      'namespace' => 'effectpay',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46a60e609f7a6c085343c19f9005b59c',
      'native_key' => 'effectpay.sberbank.is_test',
      'filename' => 'modSystemSetting/397c03ed92e966ed07d9038a96d84b49.vehicle',
      'namespace' => 'effectpay',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '557766f8ff93e4e1d57732c3db2505d2',
      'native_key' => 'effectpay.sberbank.passwords',
      'filename' => 'modSystemSetting/5842c33ebf2e4c9ddccef8b92fadc2c2.vehicle',
      'namespace' => 'effectpay',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '279bb69b6a7baf68ffb002991ca4c1d0',
      'native_key' => 'effectpay.shk.statuses',
      'filename' => 'modSystemSetting/525675e940763312d8c10439714fca09.vehicle',
      'namespace' => 'effectpay',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3053e204aaa2c859c53e4c1c066df181',
      'native_key' => 'PayCallback',
      'filename' => 'modEvent/c27d3a4c2f42c31f333bcf8cff830d22.vehicle',
      'namespace' => 'effectpay',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'd7589681d0c12f387e4c04fb881484f5',
      'native_key' => 'd7589681d0c12f387e4c04fb881484f5',
      'filename' => 'xPDOScriptVehicle/fb3aa5cbfd7338fcb347082d5cc6d53a.vehicle',
      'namespace' => 'effectpay',
    ),
  ),
);