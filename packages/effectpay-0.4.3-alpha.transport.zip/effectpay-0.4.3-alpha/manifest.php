<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectpay-0.4.3-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6903a4dfcca354134d14ca748da76729',
      'native_key' => 'effectpay',
      'filename' => 'modNamespace/a0ae3befbe6137a7b4bb201944b6599c.vehicle',
      'namespace' => 'effectpay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '23a9f6002104ace27f092216cd449afb',
      'native_key' => '23a9f6002104ace27f092216cd449afb',
      'filename' => 'xPDOScriptVehicle/9d9d32304340f13c4b61b46a76f9130b.vehicle',
      'namespace' => 'effectpay',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '683c96f4efb647967e2515314a36875f',
      'native_key' => 'PayCallback',
      'filename' => 'modEvent/13d22fa5cdba3532cba34e66a48cd7f9.vehicle',
      'namespace' => 'effectpay',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c82ff62018a6c749f4b24c00583e5587',
      'native_key' => 'effectpay.return_page',
      'filename' => 'modSystemSetting/bdbece3e70758c9ea0f626b3f8398658.vehicle',
      'namespace' => 'effectpay',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06d121eb08bf9f9e7fee5b7c80724d66',
      'native_key' => 'effectpay.tax',
      'filename' => 'modSystemSetting/8b6c2e4b4442dea9d5237e11cddbc311.vehicle',
      'namespace' => 'effectpay',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f48bd00be8af487b805cd9f4fabc158',
      'native_key' => 'effectpay.robokassa.id',
      'filename' => 'modSystemSetting/fe48f58eddd5346fad3279bdb563a2f6.vehicle',
      'namespace' => 'effectpay',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b9c0d639ae7243246542f3a15b9d219',
      'native_key' => 'effectpay.robokassa.is_test',
      'filename' => 'modSystemSetting/4215e3e2b8eb6e2da783eb6d07a1e794.vehicle',
      'namespace' => 'effectpay',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdaf3349eb58cac36a7df4ae6a1e9ee0',
      'native_key' => 'effectpay.robokassa.passwords',
      'filename' => 'modSystemSetting/0e6ecb79d59f2cf10d779a0ffa27a42a.vehicle',
      'namespace' => 'effectpay',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05331cd61c450b2ade48c34d43fe6afe',
      'native_key' => 'effectpay.sberbank.id',
      'filename' => 'modSystemSetting/79d1dee83b3a0cc93a6f7e50ab686118.vehicle',
      'namespace' => 'effectpay',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13a006a9a7d54526141acd24f2383f2a',
      'native_key' => 'effectpay.sberbank.is_test',
      'filename' => 'modSystemSetting/dd9f1f7c8638ba6bab47330320ed343f.vehicle',
      'namespace' => 'effectpay',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '541ebee990dc8b90a13a3944c38db380',
      'native_key' => 'effectpay.sberbank.passwords',
      'filename' => 'modSystemSetting/7bf137b9dd34ad7e951b51775f73fdf6.vehicle',
      'namespace' => 'effectpay',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60c59fbb40f3c5f0635a419bff670ba1',
      'native_key' => 'effectpay.paykeeper.id',
      'filename' => 'modSystemSetting/0f84848391d1ae39673678b73e2803fc.vehicle',
      'namespace' => 'effectpay',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e569be4e75cfd01f7541d403d0501f',
      'native_key' => 'effectpay.paykeeper.password',
      'filename' => 'modSystemSetting/024db850fbcae4a4c8d4a17047f46211.vehicle',
      'namespace' => 'effectpay',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '328c2033d5c3c39f5e3acbd3293b5310',
      'native_key' => 'effectpay.paykeeper.server',
      'filename' => 'modSystemSetting/8e457b8d09faff139cd7f7d380c18106.vehicle',
      'namespace' => 'effectpay',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25c002587b6853f655b747761445f2dc',
      'native_key' => 'effectpay.paykeeper.secret',
      'filename' => 'modSystemSetting/134e6c65d5062701b5cc75bf4cf58e1e.vehicle',
      'namespace' => 'effectpay',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e9890ae9b67f6c066cf3acc91547057',
      'native_key' => 'effectpay.alpha.id',
      'filename' => 'modSystemSetting/d5d5175b9ad1d6e611eeccb9170d818f.vehicle',
      'namespace' => 'effectpay',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '658c81a1b8d574b61100a9f8501eb397',
      'native_key' => 'effectpay.alpha.password',
      'filename' => 'modSystemSetting/2eaa9548ff9b10140e2f11ebca6c46d5.vehicle',
      'namespace' => 'effectpay',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2728b74e6c957dba12868b34997b1b7c',
      'native_key' => 'effectpay.shk.statuses',
      'filename' => 'modSystemSetting/f61b8e19c9ce370696166775d5f4aca0.vehicle',
      'namespace' => 'effectpay',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2739a7549935d8cc9c19505cb9ba0506',
      'native_key' => 0,
      'filename' => 'modCategory/2f5b4721d815d2deaca0acde7afb4f89.vehicle',
      'namespace' => 'effectpay',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '9f7f60cb77b0c28883912fe020b3b06f',
      'native_key' => '9f7f60cb77b0c28883912fe020b3b06f',
      'filename' => 'xPDOScriptVehicle/ad902d643ce4752a58805a1d391c6654.vehicle',
      'namespace' => 'effectpay',
    ),
  ),
);