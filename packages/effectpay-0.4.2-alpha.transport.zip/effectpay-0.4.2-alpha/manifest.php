<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectpay-0.4.2-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5d7e013ba78627de181fb3bc1b4bf4ed',
      'native_key' => 'effectpay',
      'filename' => 'modNamespace/933eca21bf32fbb61b1484202c6d96e0.vehicle',
      'namespace' => 'effectpay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c137707f1e16a780d9e448c24a8cc543',
      'native_key' => 'c137707f1e16a780d9e448c24a8cc543',
      'filename' => 'xPDOScriptVehicle/8a13a137d59293ff14b0b92235495f25.vehicle',
      'namespace' => 'effectpay',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fa63dbc843ab82b2935e39535f45040',
      'native_key' => 'PayCallback',
      'filename' => 'modEvent/b3d216613ff2b434986815f3a1f86a6d.vehicle',
      'namespace' => 'effectpay',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '407a361788e2806c6a054d4426be5565',
      'native_key' => 'effectpay.return_page',
      'filename' => 'modSystemSetting/25bb75be9759bcf242fb69f9bf47702e.vehicle',
      'namespace' => 'effectpay',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4967394a202e838743de82fc45b2b660',
      'native_key' => 'effectpay.robokassa.id',
      'filename' => 'modSystemSetting/cd1895a652e16309e5925eefb9718e66.vehicle',
      'namespace' => 'effectpay',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51b5e42cb21673526e2882e7ebaa0588',
      'native_key' => 'effectpay.robokassa.is_test',
      'filename' => 'modSystemSetting/7349e0fbfc25728183367c9beae1531f.vehicle',
      'namespace' => 'effectpay',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48ae15fdc5b85e3b7a34ab64b3a23d96',
      'native_key' => 'effectpay.robokassa.passwords',
      'filename' => 'modSystemSetting/372474ae63c5e23b2a2b0589f23ad4fa.vehicle',
      'namespace' => 'effectpay',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ba2a9bfaaabb6d91221573285fe7fa4',
      'native_key' => 'effectpay.sberbank.id',
      'filename' => 'modSystemSetting/8f01ed12c0bd2f6221fcd3d56d9b3932.vehicle',
      'namespace' => 'effectpay',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16c5b5eaedb025e6d08929268c6f9f77',
      'native_key' => 'effectpay.sberbank.is_test',
      'filename' => 'modSystemSetting/e91c1f226f33a45268014579263c6231.vehicle',
      'namespace' => 'effectpay',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4914cafdbc219744d500461f4e82bfb9',
      'native_key' => 'effectpay.sberbank.passwords',
      'filename' => 'modSystemSetting/e32199f97609cdb2ad2d2901ea8ad132.vehicle',
      'namespace' => 'effectpay',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8295a90618cb2f0567c6e3cb1d580a9c',
      'native_key' => 'effectpay.paykeeper.id',
      'filename' => 'modSystemSetting/118d7c9e4a9a1b5af1d77298693202bc.vehicle',
      'namespace' => 'effectpay',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '422b3fc5c46b58b729d3368fff4a8eec',
      'native_key' => 'effectpay.paykeeper.password',
      'filename' => 'modSystemSetting/b25804c35bedbaa0cab612175dd7aceb.vehicle',
      'namespace' => 'effectpay',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dd43563adeb7f07cee3149fbd377003',
      'native_key' => 'effectpay.paykeeper.server',
      'filename' => 'modSystemSetting/66f3dc2c79707c304fd9944ae0de03ef.vehicle',
      'namespace' => 'effectpay',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3c387a7e799dbfd096a0cd2eaf88856',
      'native_key' => 'effectpay.paykeeper.secret',
      'filename' => 'modSystemSetting/9ead8e1b1df91a91e68de1714c2f77c9.vehicle',
      'namespace' => 'effectpay',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1d429593f7726c552dd259470eee316',
      'native_key' => 'effectpay.alpha.id',
      'filename' => 'modSystemSetting/cc7996863bd1fa69ba1a7af980bfcd9f.vehicle',
      'namespace' => 'effectpay',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f9ea2ba5a7981bcdf2a0eb8ee644f67',
      'native_key' => 'effectpay.alpha.password',
      'filename' => 'modSystemSetting/0a144a43e01a5600bbb658f9567ed46e.vehicle',
      'namespace' => 'effectpay',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67874807dadef87f0aa13f575cbc2179',
      'native_key' => 'effectpay.shk.statuses',
      'filename' => 'modSystemSetting/b8a6ffa3cb33af9c7d0fcc824680294d.vehicle',
      'namespace' => 'effectpay',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7e19cd8aae960d5612b4c4cad314fd72',
      'native_key' => 0,
      'filename' => 'modCategory/2e05568af46dce4a76b975321471c281.vehicle',
      'namespace' => 'effectpay',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '14dd114a25c876ee699025fc59df3282',
      'native_key' => '14dd114a25c876ee699025fc59df3282',
      'filename' => 'xPDOScriptVehicle/e8a56e7f431a0212f71571e16856d50d.vehicle',
      'namespace' => 'effectpay',
    ),
  ),
);